# OpusMC 生存辅助 HUD — 注入操作手册

目标：给 B 站网页版 MC（`bilibili.com/toy/OpusMC`，闭源独立实现）做一个「彗星客户端」式的
运行时注入 HUD（坐标 / FPS / 血量 / 饥饿）。脚本本体是 `opusmc-hud.user.js`（v0.2.0）。

## 底细已摸清（2026-11-05 实测）

- **游戏真实地址**：B 站 Toy 只是外壳，游戏跑在 **`www.bilibilitoy.com`** 这个独立域的
  iframe 里（当前版本 `https://www.bilibilitoy.com/toy/OpusMC/47455601425408-v39426/index.html`，
  路径里的版本号会随更新变化，脚本用通配 `@match https://www.bilibilitoy.com/*` 覆盖）。
- **全局对象就叫 `window.game`**：游戏页面自己的代码就写着
  `(window.game && window.game.state !== 'boot')` —— 脚本 Tier 1 直接命中，无需断点考古。
- **源码未混淆**：游戏是 60+ 个按功能命名的独立 JS（非 bundle）。已全量下载到
  `probe/js/`（18MB），是**可读源码**，做深度 mod 时就是权威参考。类定义位置：
  `game.js`（class Game）、`entity.js`（class Entity / Living / Player）。
- 架构与 OpusCraft 同款双 canvas：`#gl`（WebGL 3D）+ `#ui`（2D HUD 层）。

## OpusMC 字段地图（照 entity.js / game.js 实测，已写进脚本适配）

| 数据 | OpusMC | OpusCraft 对照 |
|---|---|---|
| 全局对象 | `window.game` | `window.__game` |
| 坐标 | `game.player.pos = [x,y,z]`（**数组**） | `player.x / y / z` |
| 上一帧坐标 | `player.prev = [x,y,z]`（插值用） | `xo/yo/zo` |
| 速度 | `player.vel = [vx,vy,vz]` | `dx/dy/dz` |
| 朝向 | `player.yaw / pitch`（**弧度制**） | 度数制 |
| 血量 | `player.health`（满 20） | 同 |
| 饥饿 | `player.food / saturation` | 同 |
| 飞行/疾跑/潜行 | `player.flying / sprinting / sneaking` | 同 |
| 模式 | `game.mode`（'survival' 等） | `player.gameMode` |
| FPS | `game.fps` | 同 |
| 实体列表 | `game.entities` | `game.level.entities` |
| 游戏状态 | `game.state`（'boot'/'play'…） | `game.inWorld` |

## 使用（两步）

1. Chrome/Edge 装 Tampermonkey → 新建脚本 → 粘贴 `opusmc-hud.user.js` 全文 → 保存。
2. 打开 `https://www.bilibili.com/toy/OpusMC` 进游戏。左上角出现
   「OpusHUD · 已接入（game）· L 开菜单」即成功。

脚本对 `opuscraft.pages.dev` 同样生效，可以对照着玩。

## 功能（v0.3.0）

- **L 键**：开关右侧菜单（控件全为开关样式，配置存 localStorage 记住）。
- **H 键**：快速开关坐标 HUD（菜单里也能关）。
- **坐标 HUD**：XYZ / 方块坐标 / 朝向 / FPS / HP / 饥饿 / 模式 / 移速。
- **ESP 生物方框**：遍历 `game.entities`，只框生物（有 health/maxHealth 的实体）。
  敌对生物红框（类名清单来自 mobs_hostile.js）、生物蓝框、其他玩家紫框，
  方框上方带血条 + 类名 + 距离。投影直接读 `game.renderer.vp`（view×proj 合成矩阵，
  每帧更新），与游戏画面（含 fov、视角摆动、第三人称）完全对齐。
- **追踪线**：准星 → 生物方框中心。
- **ESP 距离**：菜单步进调节（8~128 格）。

## 离线完整版（断网可玩）

`probe/` 目录就是抓下来的完整游戏（90 个 JS + game.html，全部外部资源内嵌，
唯一的外部数据 credits.json 也已内嵌在 texts.js 里——资源零缺失）。

**本地双击 game.html 黑屏是正常的**：file:// 协议下 Chrome 禁 Worker（地形生成）
和 IndexedDB（存档），游戏起不来。用 `start-game.cmd` 走本地服务器：

1. 双击 `start-game.cmd`（自动开浏览器到 `http://localhost:8777/game.html`）；
2. 窗口保持开着（Ctrl+C 或关窗 = 停服）；
3. 断网也能玩，存档在你浏览器里（IndexedDB 按「来源」隔离：本地版和 B 站版存档互不相通）。

已验证：本地起服后 game.html 与全部 JS 均 200。

## v0.4.0 功能全量 + 抓取完整性审计（2026-11-05）

- **新功能**（全部菜单开关，配置记住）：
  - **实体雷达**：右下角圆形俯视图，玩家朝向为上，生物敌我分色点 + 掉落物黄点/
    经验球绿点/投射物橙点，半径随「ESP 距离」联动。
  - **方位罗盘**：顶部朝向刻度条（南/西/北/东 + 15° 刻度），绿色指针指当前朝向。
  - **物品与投射物 ESP**：掉落物/经验球/箭/火球/末影珍珠/TNT 等无血量实体画小点框
    + 中文名距离，独立于生物 ESP 开关。
  - **生物中文名**：60+ 类名→中文对照表（逐个对照 probe/js 类定义注释核对，
    Crawler=蠹虫、SulfurCube=硫磺方块、Nautilus=鹦鹉螺坐骑），标签优先显示中文。
  - **HUD 维度显示**：主世界/下界/末地。
- **抓取完整性审计**：重新备份线上原版 `game.orig.html`；全量扫描 90 个 JS 的文件
  引用，**补抓漏网之鱼 `js/emoji.webp`（116KB 表情贴图，被 emoji.js 引用）**；
  credits.json/end.txt/postcredits.txt/world.json 线上均 404（运行时走 MC_TEXTS
  内嵌数据，实体文件不存在）；favicon/manifest 404 不存在。
  **最终清单：game.html + 90 JS + emoji.webp = 线上可抓的全部，已 100% 抓齐。**
- **公告红字解释**：「不允许从这个网页访问」是 B 站服务端的来源校验（/api/news
  只允许 bilibili 域页面读取），本地版注定被拒——不是文件缺失。已在本地副本
  news.js 加域名守卫：非 B 站域跳过公告拉取，不再弹红字，单人玩法不受任何影响。
- 服务端功能（登录/公告/云存档/多人）在本地版不可用属预期，绕过校验不做。

## v0.3.3 修复与新增（2026-11-05）

- **框框不流畅**：游戏是 20Hz tick + 每帧插值渲染（`render(acc/50)`），方框原来读的
  是物理 tick 位置 `e.pos`，会 20Hz 跳变。现改用 `e.ipos(alpha)`（和游戏渲染同一插值
  参数），AABB 也按插值位置自算（`e.box()` 读的是未插值位置）——移动中的生物方框丝滑。
- **菜单点不到**：游戏在 window capture 上监听 mousedown，把**一切点击**变成指针锁定
  （main.js:72）——指针被锁定的瞬间菜单就点不着了。两路修复：开菜单时自动
  `exitPointerLock()`；菜单区域的 mousedown 在 capture 阶段就地拦截
  （`stopImmediatePropagation`，userscript 注册早于游戏脚本，拦得住）。关闭菜单后
  点一下游戏画面即恢复正常视角控制。
- **夜视（新开关）**：发现游戏渲染原生支持 `env.nightVision`（夜视药水路径，连
  shader 里都有）。菜单新增「夜视」开关，实现方式是替换全局 `nightVisionScale()`
  让强度恒为 1——走的完全是游戏自己的渲染路径，效果等同原版夜视药水满级。
- **本地版跳转真相（更正此前的说法）**：跳转代码不在 90 个 js 里，而是
  **game.html 第 219 行的内联脚本**——只要不在 iframe 里打开（本地直接开 = 顶层窗口），
  立刻 `location.replace` 回 B 站线上版。这是作者的防盗版守卫。本地副本已删除该行，
  现在 `http://localhost:8777/game.html` 就是终点，不会再跳。在线版不受影响
  （B 站 iframe 里 `self !== top`，守卫本来就不触发）。

## v0.3.2 修复记录（2026-11-05）

- **z 裁剪错杀（ESP 方框不显示的真正根因）**：`project()` 把裁剪空间的 clip.z
  当成 NDC z 按 [-1,1] 裁剪。透视投影下 clip.z 的正常范围是 -near ~ -far 的量级
  （几十到几百），按 [-1,1] 裁等于**只有约 1 米内的实体能显示**——表现为方框
  永远不出现、追踪线贴脸时偶尔闪一下、一走动就消失。已去掉 z 裁剪，只保留
  「相机后方」剔除（cw≤0），符合 ESP 宁多勿漏的语义。
- 关于「本地版跳转到 B 站」：**此前判断有误，已更正**——跳转代码是 game.html 内联的
  防盗版守卫（第 219 行，非 iframe 打开即跳回 B 站），js 文件里确实没有。本地副本
  已删除该守卫（v0.3.3 起），localhost 版不会再跳。
- 关于 GitHub 仓库：`github.com/Oppenheimerism/OpusCraft` 只是**参考架构**
  （另一个开源网页 MC），不是 OpusMC 的源码。OpusMC 闭源，我们的参考代码
  是 `probe/js/`（从线上抓的原文件），所有修改都在 userscript 里。

## v0.3.1 修复记录（2026-11-05）

- **双 frame 假实例**：Toy 外壳页（bilibili.com/toy/OpusMC）和游戏 iframe 是两个页面，
  脚本原来两边都注入 → 外壳那份「假实例」的菜单/HUD 叠在游戏上面，开关拨了
  却作用在一个没有游戏的页面（两边 localStorage 也是隔离的）。现在 boot 时检测
  `<canvas id="gl">`，只有真正的游戏页面才启动 UI。
  **操作要点：先点一下游戏画面（把键盘焦点给游戏），再按 L。**
- **ESP 画布 DPR 错位**：ESP 画布原来没有 CSS 拉伸，Windows 显示缩放不是 100% 时
  方框整体偏出屏幕。现已强制 `width/height: 100%`，与游戏画布同比映射，任意缩放都对齐。
- 修复后如果 ESP 开关是关的：进游戏按 L 重新拨一次（会记住）。

## 服务端 API 说明（回答「/api/account/* 拿得到吗」）

拿不到，也不可能拿到：`/api/account/*`、`/api/gate` 这些是跑在作者服务器上的
**服务端代码**，浏览器只收到 HTTP 响应，永远收不到服务端源码。客户端侧的调用方
（account.js、net.js、p2p.js、cloudsave.js）已在 probe/js 里，能还原「发了什么请求」，
还原不了「服务端怎么处理」。服务端没开源就没辙——主动攻击服务器属于未授权访问，
这条线不碰。**后果**：离线版单人玩法完整；多人联机依赖作者服务端，本地起不了。

## 离线版 vs 在线版怎么分辨

看浏览器地址栏：`localhost:8777` = start-game.cmd 起的本地版（断网可玩）；
`bilibili.com / bilibilitoy.com` = 在线版（你自己开的标签）。start-game.cmd 不会
打开任何 bilibili 地址。

## 如果没接入（降级策略）

- HUD 显示「还没抓到 player 引用…」并持续 5 分钟 → 自动发现失败。
  在游戏 iframe 的 console 里手动来：
  1. `__opusHud.setRef(game)` —— 直接把全局 game 递给它；
  2. 或 `__opusHud.sniffFillText()` 开启嗅探 → 玩两秒 → 看 `__opusHud.fillTextLog`
     （记录画出来的文字 + 调用源码位置）→ 去 Sources 定位 HUD 渲染函数 →
     断点断住后 `__opusHud.setRef(this)`。
- Console 记得把左上角「top ▾」切到 bilibilitoy.com 的 frame。

## 已知的坑

- **B 站更新游戏**：版本号路径会变（如 `…-v39426` 变 `-v39427`），但脚本 match 的是
  整个域，不受影响；真正会失效的是字段改名 —— 届时重新抓 `probe/js/` 对照。
- **probe/js/ 只是参考快照**（2026-11-05，v39426），游戏更新后以线上最新为准。
- **公平性边界**：坐标/FPS/血量/饥饿这类是原版 F3 就有的信息，属于显示增强；
  自动挖矿、自动战斗这类在联机房间里就是外挂，别做。

## 下一步可扩展

- 方位罗盘（读 yaw 画罗盘，注意弧度制）
- 实体雷达（扫 `game.entities` 画点位，OpusMC 的实体列表是平铺数组，比 OpusCraft 好读）
- 生物群系 / 维度显示（找 worldgen.js / dims.js 里的字段）
- 时间天气（`game.worldTime`、`game.weather`）
