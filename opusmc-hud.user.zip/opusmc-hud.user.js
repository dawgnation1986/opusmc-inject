// ==UserScript==
// @name         OpusMC 生存辅助（彗星式客户端）
// @namespace    https://github.com/bigpixel
// @version      0.4.0
// @description  网页版 MC 运行时注入：L 键菜单。坐标 HUD、ESP 生物方框（插值丝滑）、追踪线、名字血条、物品与投射物 ESP、实体雷达、方位罗盘、夜视。引用自动发现。适配 B 站 OpusMC 与 OpusCraft。
// @author       BigPixel
// @match        https://opuscraft.pages.dev/*
// @match        https://www.bilibilitoy.com/*
// @match        https://www.bilibili.com/toy/*
// @run-at       document-start
// @grant        unsafeWindow
// ==/UserScript==

(function () {
  'use strict';

  // Tampermonkey 沙箱里的 window 是代理，必须拿页面真身才能摸到游戏挂的全局对象
  const W = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;

  const REF_POLL_MS = 800;
  const REF_POLL_MAX_TRIES = 375; // 最多找 5 分钟
  const SLOW_ROWS_MS = 250;

  const state = { game: null, player: null, flavor: '' };

  // ---------- 配置 ----------
  const CFG_KEY = '__opusHudCfg';
  const cfg = Object.assign({
    hud: true,          // 坐标 HUD
    esp: false,         // ESP 生物方框
    tracers: false,     // 追踪线
    labels: true,       // 名字与血条
    itemEsp: false,     // 物品与投射物 ESP
    radar: false,       // 实体雷达
    compass: false,     // 方位罗盘
    nightVision: false, // 夜视（游戏原生渲染路径）
    espDist: 64,        // ESP 最大距离（格）
  }, (() => { try { return JSON.parse(W.localStorage.getItem(CFG_KEY) || '{}'); } catch (e) { return {}; } })());

  function saveCfg() {
    try { W.localStorage.setItem(CFG_KEY, JSON.stringify(cfg)); } catch (e) { /* 内存态兜底 */ }
  }

  // ---------- 工具 ----------
  function num(o, ...keys) {
    if (!o) return null;
    for (const k of keys) {
      try {
        const v = o[k];
        if (typeof v === 'number' && isFinite(v)) return v;
      } catch (e) { /* getter 可能抛 */ }
    }
    return null;
  }

  function vec3(o, ...keys) {
    if (!o) return null;
    for (const k of keys) {
      try {
        const v = o[k];
        if (Array.isArray(v) && typeof v[0] === 'number' && typeof v[2] === 'number') return v;
      } catch (e) { /* noop */ }
    }
    return null;
  }

  // OpusMC: p.pos=[x,y,z] yaw 弧度 | OpusCraft: p.x/y/z yaw 度数
  function readPos(p) {
    const pos = vec3(p, 'pos', 'position');
    const vel = vec3(p, 'vel', 'velocity');
    const yaw = num(p, 'yaw', 'rotationY', 'rotation');
    return {
      x: pos ? pos[0] : num(p, 'x'),
      y: pos ? pos[1] : num(p, 'y'),
      z: pos ? pos[2] : num(p, 'z'),
      vx: vel ? vel[0] : num(p, 'dx', 'vx'),
      vy: vel ? vel[1] : num(p, 'dy', 'vy'),
      vz: vel ? vel[2] : num(p, 'dz', 'vz'),
      yaw,
      pitch: num(p, 'pitch', 'rotationX'),
      health: num(p, 'health', 'hp'),
      food: num(p, 'food', 'hunger'),
      fps: num(state.game, 'fps'),
      dim: (() => { try { return state.game ? state.game.dim : null; } catch (e) { return null; } })(),
      mode: (() => {
        try {
          return p.gameMode ?? p.gamemode
            ?? (state.game ? state.game.mode : null) ?? null;
        } catch (e) { return null; }
      })(),
    };
  }

  // 朝向角：弧度（OpusMC）与度数（OpusCraft）以 7 为界自动判别
  function yawDeg(yaw) {
    if (yaw == null) return null;
    return Math.abs(yaw) <= 7 ? yaw * 180 / Math.PI : yaw;
  }
  function yawRad(yaw) {
    if (yaw == null) return 0;
    return Math.abs(yaw) <= 7 ? yaw : yaw * Math.PI / 180;
  }

  function facingOf(yaw) {
    const deg = yawDeg(yaw);
    if (deg == null) return '?';
    const dirs = ['south(+Z)', 'west(-X)', 'north(-Z)', 'east(+X)'];
    return dirs[Math.floor(((deg % 360) + 360 + 45) / 90) % 4];
  }

  const CN_DIM = { overworld: '主世界', nether: '下界', end: '末地' };

  // ---------- 生物中文名（类名 → 中文，来自 probe/js 类定义核对） ----------
  const CN_NAMES = {
    // 敌对
    ZombieKind: '僵尸', SkeletonKind: '骷髅', CaveSpider: '洞穴蜘蛛', Crawler: '蠹虫',
    Slime: '史莱姆', SulfurCube: '硫磺方块', Phantom: '幻翼', Witch: '女巫',
    Pillager: '掠夺者', Vindicator: '卫道士', Evoker: '唤魔者', Vex: '恼鬼',
    Ravager: '劫掠兽', Breeze: '旋风人', Creaking: '嘎枝', Warden: '监守者',
    Shulker: '潜影贝', Zoglin: '僵尸疣猪兽', Wither: '凋灵', EnderDragon: '末影龙',
    Blaze: '烈焰人', Ghast: '恶魂', MagmaCube: '岩浆怪', Piglin: '猪灵',
    Hoglin: '疣猪兽', ZombifiedPiglin: '僵尸猪灵', Enderman: '末影人',
    Guardian: '守卫者', Drowned: '溺尸', SnowGolem: '雪傀儡',
    // 被动
    Allay: '悦灵', Armadillo: '犰狳', Axolotl: '美西螈', Bat: '蝙蝠', Bee: '蜜蜂',
    Camel: '骆驼', Cat: '猫', Cod: '鳕鱼', Dolphin: '海豚', Fox: '狐狸', Frog: '青蛙',
    Goat: '山羊', HappyGhast: '快乐恶魂', Horse: '马', Llama: '羊驼', Mooshroom: '哞菇',
    Ocelot: '豹猫', Panda: '熊猫', Parrot: '鹦鹉', PolarBear: '北极熊', Pufferfish: '河豚',
    Rabbit: '兔子', Salmon: '鲑鱼', Sniffer: '嗅探兽', Squid: '鱿鱼', Strider: '炽足兽',
    Tadpole: '蝌蚪', TropicalFish: '热带鱼', Turtle: '海龟', Wolf: '狼', Villager: '村民',
    WanderingTrader: '流浪商人', Nautilus: '鹦鹉螺',
    // 物品与投射物
    ItemEntity: '掉落物', Arrow: '箭', ExperienceOrb: '经验球', Fireball: '火球',
    ThrownPearl: '末影珍珠', PrimedTNT: '点燃的TNT', WitherSkull: '凋灵之首',
    ShulkerBullet: '潜影弹', DragonFireball: '龙息火球', EyeOfEnder: '末影之眼',
    FallingBlock: '掉落方块', EvokerFangs: '唤魔者尖牙', AreaCloud: '药水云',
  };
  function cnName(e) {
    const n = (e && e.constructor && e.constructor.name) || '?';
    return CN_NAMES[n] || n;
  }

  // 物品/投射物分类（无 health 的实体），返回颜色或 null（不显示）
  const PROJ = new Set(['Arrow', 'Fireball', 'ThrownPearl', 'WitherSkull', 'ShulkerBullet',
    'DragonFireball', 'EyeOfEnder', 'MobShot', 'PrimedTNT', 'EvokerFangs']);
  function itemKindOf(e) {
    const n = (e && e.constructor && e.constructor.name) || '';
    if (n === 'ItemEntity') return '#ffd54f';      // 掉落物（黄）
    if (n === 'ExperienceOrb') return '#69f0ae';   // 经验球（绿）
    if (PROJ.has(n)) return '#ff8a65';             // 投射物（橙红）
    if (n === 'FallingBlock' || n === 'AreaCloud') return '#b0bec5'; // 其他（灰）
    return null;
  }

  // ---------- 引用发现 Tier 1：全局挂载（OpusMC: window.game / OpusCraft: window.__game） ----------
  function tryGlobalMount() {
    for (const key of ['game', '__game', 'G', 'engine', '__OPUS', 'mc', 'world']) {
      try {
        const g = W[key];
        if (g && typeof g === 'object') {
          if (g.player && looksLikePlayer(g.player)) return { game: g, player: g.player, key };
          if (looksLikePlayer(g)) return { game: null, player: g, key };
        }
      } catch (e) { /* 忽略跨域/抛错属性 */ }
    }
    return null;
  }

  function looksLikePlayer(o) {
    try {
      if (!o || typeof o !== 'object') return false;
      const hasYaw = typeof o.yaw === 'number' || typeof o.rotationY === 'number';
      if (!hasYaw) return false;
      if (typeof o.x === 'number' && typeof o.y === 'number' && typeof o.z === 'number') return true;
      if (Array.isArray(o.pos) && typeof o.pos[0] === 'number') return true;
      return false;
    } catch (e) { return false; }
  }

  function scanWindow() {
    let keys;
    try { keys = Object.getOwnPropertyNames(W); } catch (e) { return null; }
    for (const key of keys) {
      let v;
      try { v = W[key]; } catch (e) { continue; }
      if (!v || typeof v !== 'object' || v === W || v === W.document) continue;
      if (looksLikePlayer(v)) return { game: null, player: v, key };
      let sub;
      try { sub = Object.getOwnPropertyNames(v); } catch (e) { continue; }
      if (sub.length > 300) continue;
      for (const sk of sub) {
        let sv;
        try { sv = v[sk]; } catch (e) { continue; }
        if (sv && typeof sv === 'object' && looksLikePlayer(sv)) {
          return { game: v, player: sv, key: key + '.' + sk };
        }
      }
    }
    return null;
  }

  // ---------- 引用发现 Tier 3：hook fillText 嗅探 ----------
  function installFillTextSniffer() {
    if (W.__opusHud && W.__opusHud._snifferInstalled) return;
    const orig = CanvasRenderingContext2D.prototype.fillText;
    CanvasRenderingContext2D.prototype.fillText = function (text, x, y) {
      const h = W.__opusHud;
      if (h && h._sniffing) {
        h._sniffing.count++;
        if (h._sniffing.count <= 400) {
          let where = '(native)';
          try {
            where = new Error().stack.split('\n')[2]?.trim().slice(0, 120) ?? '(?)';
          } catch (e) { /* noop */ }
          h.fillTextLog.push({
            text: String(text).slice(0, 60),
            canvas: (this.canvas && (this.canvas.id || this.canvas.className)) || '(unnamed)',
            where,
          });
        }
      }
      return orig.call(this, text, x, y);
    };
    if (W.__opusHud) W.__opusHud._snifferInstalled = true;
  }

  // ---------- CSS（集中一个 style 块，DOM 只用类名） ----------
  const css = `
    #__opus_hud {
      position: fixed; left: 8px; top: 8px; z-index: 2147483647;
      font: 12px/1.5 Consolas, Menlo, monospace; color: #e8e8e8;
      background: rgba(16,16,16,0.55); border: 1px solid rgba(255,255,255,0.18);
      border-radius: 6px; padding: 6px 10px; pointer-events: none;
      text-shadow: 0 1px 2px #000; white-space: pre;
    }
    #__opus_hud .op-title { color: #7fd48a; font-weight: bold; margin-bottom: 2px; }
    #__opus_menu {
      position: fixed; right: 16px; top: 64px; z-index: 2147483647;
      width: 224px; max-height: calc(100vh - 90px); overflow-y: auto;
      font: 13px/1.4 "Segoe UI", "Microsoft YaHei", sans-serif;
      color: #e8e8e8; background: rgba(20,22,26,0.92);
      border: 1px solid rgba(255,255,255,0.15); border-radius: 10px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.45); user-select: none;
    }
    #__opus_menu.op-hidden { display: none; }
    .op-menu-head {
      display: flex; align-items: center; justify-content: space-between;
      padding: 10px 14px; background: rgba(127,212,138,0.12);
      border-bottom: 1px solid rgba(255,255,255,0.08);
      position: sticky; top: 0; backdrop-filter: blur(4px);
    }
    .op-menu-title { font-weight: 600; color: #7fd48a; letter-spacing: 0.5px; }
    .op-menu-close {
      width: 24px; height: 24px; line-height: 22px; text-align: center;
      border-radius: 6px; cursor: pointer; color: #999; font-size: 14px;
    }
    .op-menu-close:hover { background: rgba(255,255,255,0.1); color: #fff; }
    .op-row {
      display: flex; align-items: center; justify-content: space-between;
      padding: 9px 14px; min-height: 44px; cursor: pointer;
    }
    .op-row:hover { background: rgba(255,255,255,0.05); }
    .op-row.op-static, .op-row.op-static:hover { cursor: default; background: transparent; }
    .op-row .op-label { color: #ddd; }
    .op-row .op-hint { color: #777; font-size: 11px; display: block; margin-top: 1px; }
    .op-switch {
      position: relative; flex: 0 0 auto; width: 40px; height: 22px;
      border-radius: 11px; background: #3a3f47; transition: background 0.15s;
    }
    .op-switch::after {
      content: ""; position: absolute; left: 3px; top: 3px;
      width: 16px; height: 16px; border-radius: 50%; background: #cfd4da;
      transition: transform 0.15s;
    }
    .op-switch.on { background: #4e9d5f; }
    .op-switch.on::after { transform: translateX(18px); background: #fff; }
    .op-stepper { display: flex; align-items: center; gap: 8px; }
    .op-step-btn {
      width: 26px; height: 26px; line-height: 24px; text-align: center;
      border: 1px solid rgba(255,255,255,0.2); border-radius: 6px;
      cursor: pointer; color: #ddd; font-size: 14px;
    }
    .op-step-btn:hover { background: rgba(255,255,255,0.1); }
    .op-step-val { min-width: 34px; text-align: center; color: #7fd48a; font-weight: 600; }
    .op-menu-foot {
      padding: 7px 14px; color: #666; font-size: 11px;
      border-top: 1px solid rgba(255,255,255,0.08);
    }
    #__opus_esp { position: fixed; left: 0; top: 0; width: 100%; height: 100%; z-index: 2147483646; pointer-events: none; }
    #__opus_radar {
      position: fixed; right: 12px; bottom: 12px; z-index: 2147483645; pointer-events: none;
      border-radius: 50%; box-shadow: 0 2px 10px rgba(0,0,0,0.4);
    }
    #__opus_compass {
      position: fixed; left: 50%; top: 6px; transform: translateX(-50%);
      z-index: 2147483645; pointer-events: none;
      box-shadow: 0 2px 8px rgba(0,0,0,0.35); border-radius: 7px;
    }
  `;
  const styleEl = document.createElement('style');
  styleEl.textContent = css;

  // ---------- HUD 文本层 ----------
  const hud = document.createElement('div');
  hud.id = '__opus_hud';
  const titleRow = document.createElement('div');
  titleRow.className = 'op-title';
  titleRow.textContent = 'OpusHUD · 按 L 开菜单';
  const bodyRow = document.createElement('div');
  hud.append(titleRow, bodyRow);

  let lastSlow = 0;
  const slowCache = { fps: null, health: null, food: null, mode: null, dim: null };

  function frame(now) {
    try {
      const p = state.player;
      if (!p) {
        bodyRow.textContent = '还没抓到 player 引用…（见 README 手册）';
      } else {
        const d = readPos(p);
        const speed = (d.vx != null) ? Math.hypot(d.vx, d.vy ?? 0, d.vz ?? 0) : null;
        const coords = `XYZ  ${fmt(d.x)}  ${fmt(d.y)}  ${fmt(d.z)}\n`
          + `Block  ${d.x == null ? '?' : Math.floor(d.x)} ${d.y == null ? '?' : Math.floor(d.y)} ${d.z == null ? '?' : Math.floor(d.z)}\n`
          + `Facing  ${facingOf(d.yaw)}  yaw=${fmt(d.yaw)} pitch=${fmt(d.pitch)}`
          + (speed != null ? `  spd=${speed.toFixed(2)}` : '');
        if (now - lastSlow > SLOW_ROWS_MS) {
          lastSlow = now;
          slowCache.fps = d.fps;
          slowCache.health = d.health;
          slowCache.food = d.food;
          slowCache.mode = d.mode;
          slowCache.dim = d.dim ? (CN_DIM[d.dim] || d.dim) : null;
        }
        const slow = `FPS  ${slowCache.fps ?? '-'}   HP  ${slowCache.health ?? '-'}`
          + `   饥饿  ${slowCache.food ?? '-'}   ${slowCache.dim ?? ''}   ${slowCache.mode ?? ''}`;
        bodyRow.textContent = coords + '\n' + slow;
      }
    } catch (e) {
      bodyRow.textContent = 'HUD 出错: ' + e.message;
    }
    if (cfg.hud) requestAnimationFrame(frame);
    else hud.style.display = 'none';
  }

  function startHud() {
    hud.style.display = '';
    requestAnimationFrame(frame);
  }

  function fmt(v) {
    return v == null ? '?' : (Math.round(v * 1000) / 1000).toFixed(3);
  }

  // ---------- ESP / 雷达 / 罗盘 ----------
  const espCanvas = document.createElement('canvas');
  espCanvas.id = '__opus_esp';
  const ectx = espCanvas.getContext('2d');

  const radar = document.createElement('canvas');
  radar.id = '__opus_radar';
  radar.width = 140; radar.height = 140;
  const rctx = radar.getContext('2d');

  const compass = document.createElement('canvas');
  compass.id = '__opus_compass';
  compass.width = 440; compass.height = 26;
  const cctx = compass.getContext('2d');

  // 敌对生物类名（probe/js/mobs_hostile.js + entity.js 实测）
  const HOSTILE = new Set([
    'SkeletonKind', 'ZombieKind', 'CaveSpider', 'Crawler', 'Slime', 'SulfurCube',
    'Phantom', 'Witch', 'Illager', 'Pillager', 'Vindicator', 'Evoker', 'EvokerFangs',
    'Vex', 'Ravager', 'Breeze', 'Creaking', 'Warden', 'Shulker', 'Zoglin', 'Wither',
  ]);
  const COLORS = {
    hostile: '#ff5252',
    passive: '#4fc3f7',
    player: '#c084fc',
    line: 'rgba(255,82,82,0.65)',
    text: '#ffffff',
    hpBg: 'rgba(0,0,0,0.55)',
    hpFill: '#69f0ae',
  };

  function colorOf(e) {
    const name = e.constructor?.name ?? '';
    if (name === 'Player') return COLORS.player;
    if (HOSTILE.has(name)) return COLORS.hostile;
    return COLORS.passive;
  }

  // 世界 → 屏幕投影：读游戏 renderer 的 vp 矩阵（列主序），与游戏渲染完全同参
  function project(v, x, y, z, w_, h_) {
    const m = v.vp;
    const cw = m[3] * x + m[7] * y + m[11] * z + m[15];
    if (cw <= 0.0001) return null; // 相机后方剔除（cw = -z_eye，后方为负）
    const cx = m[0] * x + m[4] * y + m[8] * z + m[12];
    const cy = m[1] * x + m[5] * y + m[9] * z + m[13];
    // 注意：不要用 clip.z 做 [-1,1] 裁剪 —— 透视投影下 clip.z 的范围是 -(far) ~ -(near)
    // 量级（除以 cw 才是 NDC z）。v0.3.1 及之前在这里错裁了 1 米外的所有实体。
    return { x: (cx / cw * 0.5 + 0.5) * w_, y: (1 - (cy / cw * 0.5 + 0.5)) * h_ };
  }

  function espFrame() {
    requestAnimationFrame(espFrame);
    const anyOn = cfg.esp || cfg.tracers || cfg.itemEsp || cfg.radar || cfg.compass;
    if (!anyOn) { ectx.clearRect(0, 0, espCanvas.width, espCanvas.height); return; }
    const g = state.game, p = state.player;
    if (!g || !p) return;
    const r = g.renderer;
    if (!r || !r.vp || !r.camPos) return;
    // 渲染插值：游戏 20Hz tick 后每帧按 alpha 插值渲染（game.js run(): render(acc/50)），
    // 方框用同一 alpha 才不会 20Hz 抖动
    const alpha = (g.pauseA != null) ? g.pauseA
      : (typeof g.acc === 'number' && isFinite(g.acc) ? Math.max(0, Math.min(1, g.acc / 50)) : 1);

    // 尺寸跟随 #gl 的物理像素
    const glCv = g.canvas;
    if (!glCv) return;
    if (espCanvas.width !== glCv.width || espCanvas.height !== glCv.height) {
      espCanvas.width = glCv.width;
      espCanvas.height = glCv.height;
    }
    ectx.clearRect(0, 0, espCanvas.width, espCanvas.height);

    const W_ = espCanvas.width, H_ = espCanvas.height;
    const cam = r.camPos;
    const maxD2 = cfg.espDist * cfg.espDist;
    let ents;
    try { ents = g.entities; } catch (e) { return; }
    if (!Array.isArray(ents)) return;

    for (const e of ents) {
      try {
        if (!e || e === p || e.dead) continue;
        const isMob = e.health != null && e.maxHealth != null; // 生物（Living）
        let kind = null;
        if (!isMob) {
          if (!cfg.itemEsp) continue;
          kind = itemKindOf(e);
          if (!kind) continue;
        }
        let pos;
        try {
          pos = (typeof e.ipos === 'function') ? e.ipos(alpha)
            : (Array.isArray(e.pos) ? e.pos.slice() : null);
        } catch (err) { pos = null; }
        if (!pos || typeof pos[0] !== 'number') {
          pos = Array.isArray(e.pos) ? e.pos : (typeof e.x === 'number' ? [e.x, e.y, e.z] : null);
        }
        if (!pos) continue;
        const dx = pos[0] - cam[0], dy = pos[1] - cam[1], dz = pos[2] - cam[2];
        if (dx * dx + dy * dy + dz * dz > maxD2) continue;

        // AABB（插值位置自算）：生物全框，物品/投射物画小点框
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity, ok = true;
        if (isMob) {
          const hw = (num(e, 'w') ?? 0.6) / 2, hh = num(e, 'h') ?? 1.8;
          const bb = [pos[0] - hw, pos[1], pos[2] - hw, pos[0] + hw, pos[1] + hh, pos[2] + hw];
          for (let i = 0; i < 8 && ok; i++) {
            const pt = project(r, bb[i & 1 ? 3 : 0], bb[i & 2 ? 4 : 1], bb[i & 4 ? 5 : 2], W_, H_);
            if (!pt) { ok = false; break; }
            if (pt.x < minX) minX = pt.x; if (pt.x > maxX) maxX = pt.x;
            if (pt.y < minY) minY = pt.y; if (pt.y > maxY) maxY = pt.y;
          }
        } else {
          const pt = project(r, pos[0], pos[1], pos[2], W_, H_);
          if (pt) { const s = 5; minX = pt.x - s; maxX = pt.x + s; minY = pt.y - s; maxY = pt.y + s; }
          else ok = false;
        }
        if (!ok || maxX <= minX || maxY <= minY) continue;

        const color = isMob ? colorOf(e) : kind;
        const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;

        if (cfg.tracers && isMob) {
          ectx.strokeStyle = HOSTILE.has(e.constructor?.name) ? COLORS.line : 'rgba(79,195,247,0.5)';
          ectx.lineWidth = 1;
          ectx.beginPath();
          ectx.moveTo(W_ / 2, H_ / 2);
          ectx.lineTo(cx, cy);
          ectx.stroke();
        }

        if ((cfg.esp && isMob) || (cfg.itemEsp && !isMob)) {
          ectx.strokeStyle = color;
          ectx.lineWidth = isMob ? 1.5 : 1;
          ectx.strokeRect(minX, minY, maxX - minX, maxY - minY);
        }

        if (cfg.labels && (isMob || cfg.itemEsp)) {
          const name = cnName(e);
          const dist = Math.hypot(dx, dy, dz);
          ectx.font = '11px Consolas, Menlo, monospace';
          ectx.textAlign = 'center';
          if (isMob) {
            const hp = Math.max(0, e.health) / e.maxHealth;
            const barW = Math.max(28, maxX - minX), barH = 4;
            const barX = cx - barW / 2, barY = minY - 9;
            ectx.fillStyle = COLORS.hpBg;
            ectx.fillRect(barX, barY, barW, barH);
            ectx.fillStyle = COLORS.hpFill;
            ectx.fillRect(barX, barY, barW * Math.min(1, hp), barH);
            ectx.fillStyle = COLORS.text;
            ectx.fillText(`${name} ${dist.toFixed(0)}m`, cx, barY - 4);
          } else {
            ectx.fillStyle = color;
            ectx.fillText(`${name} ${dist.toFixed(0)}m`, cx, minY - 3);
          }
          ectx.textAlign = 'start';
        }
      } catch (err) { /* 单个实体出错不影响整体 */ }
    }
  }

  // ---------- 实体雷达（俯视点位，玩家朝向为上） ----------
  function drawRadar() {
    const size = radar.width, c = rctx;
    c.clearRect(0, 0, size, size);
    if (!cfg.radar) return;
    const g = state.game, p = state.player;
    if (!g || !p || !g.renderer || !g.renderer.camPos) return;
    const cx = size / 2, cy = size / 2, R = size / 2 - 4;
    const cam = g.renderer.camPos;
    const yaw = yawRad(num(p, 'yaw'));
    const fx = -Math.sin(yaw), fz = Math.cos(yaw); // 前向（yaw=0 面南 +Z）
    const rx = -fz, rz = fx;                        // 右向（面南时右手 = 西）
    const scale = R / Math.max(8, cfg.espDist);
    const px = (dx, dz) => cx + (dx * rx + dz * rz) * scale;
    const py = (dx, dz) => cy - (dx * fx + dz * fz) * scale;

    c.save();
    c.beginPath(); c.arc(cx, cy, R, 0, Math.PI * 2); c.clip();
    c.fillStyle = 'rgba(12,14,16,0.62)';
    c.fillRect(0, 0, size, size);
    c.strokeStyle = 'rgba(255,255,255,0.15)';
    c.beginPath(); c.arc(cx, cy, R / 2, 0, Math.PI * 2); c.stroke();

    let ents; try { ents = g.entities; } catch (e) { ents = null; }
    if (Array.isArray(ents)) {
      for (const e of ents) {
        try {
          if (!e || e === p || e.dead) continue;
          const pos = Array.isArray(e.pos) ? e.pos : null;
          if (!pos) continue;
          const dx = pos[0] - cam[0], dz = pos[2] - cam[2];
          if (dx * dx + dz * dz > cfg.espDist * cfg.espDist) continue;
          const isMob = e.health != null && e.maxHealth != null;
          const name = e.constructor?.name ?? '';
          c.fillStyle = isMob ? colorOf(e)
            : (name === 'ItemEntity' ? '#ffd54f' : name === 'ExperienceOrb' ? '#69f0ae' : '#ff8a65');
          c.beginPath();
          c.arc(px(dx, dz), py(dx, dz), isMob ? 3 : 2, 0, Math.PI * 2);
          c.fill();
        } catch (err) { /* noop */ }
      }
    }
    c.restore();
    c.strokeStyle = 'rgba(255,255,255,0.3)';
    c.beginPath(); c.arc(cx, cy, R, 0, Math.PI * 2); c.stroke();
    // 中心玩家（朝上前三角）
    c.fillStyle = '#ffffff';
    c.beginPath();
    c.moveTo(cx, cy - 5); c.lineTo(cx - 4, cy + 4); c.lineTo(cx + 4, cy + 4);
    c.closePath(); c.fill();
  }

  // ---------- 方位罗盘（顶部横条，南/西/北/东） ----------
  function drawCompass() {
    const w = compass.width, h = compass.height, c = cctx;
    c.clearRect(0, 0, w, h);
    if (!cfg.compass) return;
    const p = state.player;
    if (!p) return;
    const deg = yawDeg(num(p, 'yaw')) ?? 0;
    const pxPerDeg = 6;
    c.fillStyle = 'rgba(12,14,16,0.6)';
    c.beginPath();
    if (c.roundRect) c.roundRect(0, 0, w, h, 7); else c.rect(0, 0, w, h);
    c.fill();
    c.textAlign = 'center'; c.textBaseline = 'middle';
    for (let a = 0; a < 360; a += 15) {
      const diff = ((a - deg + 180) % 360 + 360) % 360 - 180;
      const x = w / 2 + diff * pxPerDeg;
      if (x < 6 || x > w - 6) continue;
      const big = a % 90 === 0;
      c.strokeStyle = big ? 'rgba(255,255,255,0.75)' : 'rgba(255,255,255,0.22)';
      c.beginPath();
      c.moveTo(x, h - (big ? 11 : 7)); c.lineTo(x, h - 3);
      c.stroke();
      if (big) {
        c.fillStyle = 'rgba(255,255,255,0.92)';
        c.font = 'bold 12px "Microsoft YaHei", sans-serif';
        c.fillText({ 0: '南', 90: '西', 180: '北', 270: '东' }[a], x, 9);
      }
    }
    // 中心指针
    c.fillStyle = '#7fd48a';
    c.fillRect(w / 2 - 1, h - 12, 2, 10);
  }

  // ---------- 菜单（L 键开关，控件全用开关样式） ----------
  const menu = document.createElement('div');
  menu.id = '__opus_menu';
  menu.className = 'op-hidden';

  function buildMenu() {
    const head = document.createElement('div');
    head.className = 'op-menu-head';
    const t = document.createElement('span');
    t.className = 'op-menu-title';
    t.textContent = 'OpusHUD 菜单';
    const closeBtn = document.createElement('span');
    closeBtn.className = 'op-menu-close';
    closeBtn.textContent = '✕';
    closeBtn.addEventListener('click', () => toggleMenu(false));
    head.append(t, closeBtn);

    const mkSwitchRow = (label, hint, key, onChange) => {
      const row = document.createElement('div');
      row.className = 'op-row';
      const lab = document.createElement('span');
      lab.className = 'op-label';
      lab.textContent = label;
      if (hint) {
        const h = document.createElement('span');
        h.className = 'op-hint';
        h.textContent = hint;
        lab.appendChild(h);
      }
      const sw = document.createElement('span');
      sw.className = 'op-switch' + (cfg[key] ? ' on' : '');
      row.append(lab, sw);
      row.addEventListener('click', () => {
        cfg[key] = !cfg[key];
        sw.classList.toggle('on', cfg[key]);
        saveCfg();
        if (onChange) onChange(cfg[key]);
      });
      return { row, sw };
    };

    const mkStepperRow = (label, key, step, min, max) => {
      const row = document.createElement('div');
      row.className = 'op-row op-static';
      const lab = document.createElement('span');
      lab.className = 'op-label';
      lab.textContent = label;
      const st = document.createElement('span');
      st.className = 'op-stepper';
      const minus = document.createElement('span');
      minus.className = 'op-step-btn';
      minus.textContent = '−';
      const val = document.createElement('span');
      val.className = 'op-step-val';
      val.textContent = cfg[key];
      const plus = document.createElement('span');
      plus.className = 'op-step-btn';
      plus.textContent = '＋';
      const clampSet = (v) => {
        cfg[key] = Math.max(min, Math.min(max, v));
        val.textContent = cfg[key];
        saveCfg();
      };
      minus.addEventListener('click', () => clampSet(cfg[key] - step));
      plus.addEventListener('click', () => clampSet(cfg[key] + step));
      st.append(minus, val, plus);
      row.append(lab, st);
      return row;
    };

    const body = document.createElement('div');
    const swHud = mkSwitchRow('坐标 HUD', '左上角坐标 / FPS / HP / 维度', 'hud', (on) => {
      hud.style.display = on ? '' : 'none';
      if (on) startHud();
    });
    const swEsp = mkSwitchRow('ESP 生物方框', '敌对红 / 生物蓝 / 玩家紫', 'esp');
    const swTra = mkSwitchRow('追踪线', '准星 → 生物', 'tracers');
    const swLab = mkSwitchRow('名字与血条', '中文生物名 + 距离', 'labels');
    const swItem = mkSwitchRow('物品与投射物', '掉落物 / 箭 / 经验球 / 火球', 'itemEsp');
    const swRadar = mkSwitchRow('实体雷达', '右下角俯视点位，朝向为上', 'radar');
    const swComp = mkSwitchRow('方位罗盘', '顶部朝向刻度条', 'compass');
    const swNv = mkSwitchRow('夜视', '黑暗中看得见（游戏原生渲染路径）', 'nightVision');
    menuSwitches = [
      { key: 'hud', sw: swHud.sw },
      { key: 'esp', sw: swEsp.sw },
      { key: 'tracers', sw: swTra.sw },
      { key: 'labels', sw: swLab.sw },
      { key: 'itemEsp', sw: swItem.sw },
      { key: 'radar', sw: swRadar.sw },
      { key: 'compass', sw: swComp.sw },
      { key: 'nightVision', sw: swNv.sw },
    ];
    body.append(swHud.row, swEsp.row, swTra.row, swLab.row, swItem.row,
      swRadar.row, swComp.row, swNv.row,
      mkStepperRow('ESP 距离', 'espDist', 8, 8, 128));

    const foot = document.createElement('div');
    foot.className = 'op-menu-foot';
    foot.textContent = 'L 键开关此菜单 · 仅建议单人世界使用';

    menu.append(head, body, foot);
  }

  function toggleMenu(force) {
    const show = force != null ? force : menu.classList.contains('op-hidden');
    menu.classList.toggle('op-hidden', !show);
    // 打开菜单必须松开鼠标指针：游戏锁着指针时菜单看得见却点不到
    if (show) {
      try { if (document.pointerLockElement) document.exitPointerLock(); } catch (err) { }
      try { if (state.game && state.game.releasePointer) state.game.releasePointer(); } catch (err) { }
    }
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'l' || e.key === 'L') toggleMenu();
    if (e.key === 'h' || e.key === 'H') {
      cfg.hud = !cfg.hud;
      saveCfg();
      hud.style.display = cfg.hud ? '' : 'none';
      if (cfg.hud) startHud();
      syncSwitches();
    }
  }, true);

  let menuSwitches = [];
  function syncSwitches() {
    menuSwitches.forEach(({ key, sw }) => sw.classList.toggle('on', cfg[key]));
  }

  // ---------- 夜视：游戏渲染原生支持 env.nightVision（夜视药水），替换全局换算函数 ----------
  function hookNightVision() {
    if (typeof W.nightVisionScale !== 'function') {
      console.warn('[OpusHUD] nightVisionScale 不存在，夜视开关不可用');
      return;
    }
    const orig = W.nightVisionScale;
    W.nightVisionScale = function (p) {
      const v = orig.call(this, p);
      try { return cfg.nightVision ? Math.max(v, 1) : v; } catch (err) { return v; }
    };
  }

  // ---------- 装配 ----------
  function boot() {
    // 只在真正的游戏页面启动 UI：游戏 HTML 里有静态的 <canvas id="gl">，
    // B 站 Toy 外壳页没有。外壳页那份实例是「假身」——它的菜单开关存在自己的
    // localStorage 里，永远作用于一个没有游戏的页面。
    if (!document.getElementById('gl')) {
      console.log('[OpusHUD] 当前是 Toy 外壳页（无 #gl 画布），跳过注入，只在游戏画面里生效。');
      return;
    }
    installFillTextSniffer();
    hookNightVision();
    document.head.appendChild(styleEl);
    document.documentElement.append(hud, espCanvas, radar, compass, menu);
    // 游戏在 window capture 上把一切 mousedown 变成指针锁定（main.js:72），
    // 菜单区域的点击必须就地拦截。我们先于游戏脚本注册，stopImmediatePropagation 才拦得住；
    // click 事件不受影响，菜单开关照常工作。
    W.addEventListener('mousedown', (ev) => {
      if (menu && menu.contains(ev.target)) { ev.stopImmediatePropagation(); ev.preventDefault(); }
    }, true);
    buildMenu();
    startHud();
    requestAnimationFrame(espFrame);
    pollRef(0);
  }

  function pollRef(tries) {
    if (state.player) return;
    const found = tryGlobalMount() || scanWindow();
    if (found) {
      state.game = found.game;
      state.player = found.player;
      state.flavor = found.key;
      titleRow.textContent = `OpusHUD · 已接入（${found.key}）· L 开菜单`;
      console.log('[OpusHUD] 引用接入成功:', found.key, { game: found.game, player: found.player });
      return;
    }
    if (tries < REF_POLL_MAX_TRIES) setTimeout(() => pollRef(tries + 1), REF_POLL_MS);
    else titleRow.textContent = 'OpusHUD · 自动发现失败，用 __opusHud.setRef() 手动接入';
  }

  W.__opusHud = {
    setRef(obj) {
      if (!obj) return '传个对象进来';
      if (obj.player && looksLikePlayer(obj.player)) {
        state.game = obj; state.player = obj.player;
      } else if (looksLikePlayer(obj)) {
        state.player = obj;
      } else {
        return '这个对象不像 game/player（没找到坐标字段）';
      }
      titleRow.textContent = 'OpusHUD · 手动接入成功 · L 开菜单';
      return 'OK';
    },
    sniffFillText() {
      this._sniffing = { count: 0 };
      this.fillTextLog = [];
      return '嗅探已开启，玩两秒再看 __opusHud.fillTextLog';
    },
    stopSniff() { this._sniffing = null; },
    toggleMenu,
    toggleHud() {
      cfg.hud = !cfg.hud;
      saveCfg();
      hud.style.display = cfg.hud ? '' : 'none';
      if (cfg.hud) startHud();
      syncSwitches();
    },
    destroy() {
      hud.remove(); espCanvas.remove(); radar.remove(); compass.remove();
      menu.remove(); styleEl.remove();
      delete W.__opusHud;
    },
    cfg,
    fillTextLog: [],
    _sniffing: null,
    _snifferInstalled: false,
    state,
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
